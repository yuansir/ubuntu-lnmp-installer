
	/* $Id: fpm_php_trace.h,v 1.2 2008/05/24 17:38:47 anight Exp $ */
	/* (c) 2007,2008 Andrei Nigmatulin */

#ifndef FPM_PHP_TRACE_H
#define FPM_PHP_TRACE_H 1

struct fpm_child_s;

void fpm_php_trace(struct fpm_child_s *);

#endif

